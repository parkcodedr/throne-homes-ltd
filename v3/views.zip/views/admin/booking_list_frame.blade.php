@extends ('admin.main')

@push('css')


@endpush

@section('content')

<!-- start navigation -->
  @include('admin.backlayouts.booking_list')
<!-- end navigation -->




@endsection
@push('scripts')


@endpush