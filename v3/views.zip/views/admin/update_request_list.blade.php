@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.update_request_list')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
