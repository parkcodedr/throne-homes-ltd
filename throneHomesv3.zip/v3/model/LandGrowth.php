<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LandGrowth extends Model
{
    //
    protected $table = "land_growth";
    protected $guarded = [];
}
