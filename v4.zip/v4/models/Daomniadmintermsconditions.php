<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomniadmintermsconditions extends Model
{
    protected $table = 'daomni_admin_terms_conditions';
}
