<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LandGrowthRate extends Model
{
    //
    protected $table = "land_growth_rate";
}
