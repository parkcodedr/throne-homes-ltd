<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DaomniprojectImage extends Model
{
    //
    protected $table = 'daomni_projectsimages';
     protected $guarded = [];
}