<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnisettingindexlands extends Model
{
    protected $table = 'daomni_setting_index_lands';
}
