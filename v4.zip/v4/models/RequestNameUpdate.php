<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RequestNameUpdate extends Model
{
    //
    protected $guarded = [];
    protected $table = "request_name_update";
}
