<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomniprojects extends Model
{
    //
    protected $table = 'daomni_projects';
     protected $guarded = [];
}