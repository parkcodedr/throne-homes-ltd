<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnilanddetailimage extends Model
{
    protected $table = 'daomni_landdetail_images';
}
