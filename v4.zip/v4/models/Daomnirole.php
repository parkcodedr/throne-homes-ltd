<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnirole extends Model
{
    protected $table = 'daomni_roles';
}
