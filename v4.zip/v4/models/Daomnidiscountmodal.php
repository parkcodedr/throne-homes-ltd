<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnidiscountmodal extends Model
{
    protected $table = 'daomni_discount_modal';
}
