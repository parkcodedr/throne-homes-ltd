<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DaomniDownpayment extends Model
{
    protected $table = 'daomni_downpayments';
}
