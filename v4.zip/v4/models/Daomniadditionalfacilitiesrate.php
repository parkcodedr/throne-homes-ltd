<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomniadditionalfacilitiesrate extends Model
{
    protected $table = 'daomni_additional_facilities_rates';
}
