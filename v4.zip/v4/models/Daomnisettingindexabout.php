<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnisettingindexabout extends Model
{
    protected $table = 'daomni_setting_index_about';
}
