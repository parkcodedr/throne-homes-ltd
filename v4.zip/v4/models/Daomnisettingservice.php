<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnisettingservice extends Model
{
    protected $table = 'daomni_setting_services';
}
