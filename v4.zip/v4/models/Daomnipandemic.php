<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnipandemic extends Model
{
    protected $table = 'daomni_pandemics';
}
