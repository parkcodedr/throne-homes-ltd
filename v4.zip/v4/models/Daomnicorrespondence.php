<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnicorrespondence extends Model
{
    protected $table = 'daomni_correspondences';
}
