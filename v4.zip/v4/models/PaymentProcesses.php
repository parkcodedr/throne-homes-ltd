<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentProcesses extends Model
{
    //
    protected $table = "payment_processes";
    protected $guarded = [];
}
