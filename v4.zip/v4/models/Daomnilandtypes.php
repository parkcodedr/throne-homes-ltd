<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnilandtypes extends Model
{
    protected $table = 'daomni_landtypes';
}
