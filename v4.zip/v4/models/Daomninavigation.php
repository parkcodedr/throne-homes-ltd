<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomninavigation extends Model
{
    protected $table = 'daomni_setting_navs';
}
