<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnicontact extends Model
{
    protected $table = 'daomni_contacts';
}
