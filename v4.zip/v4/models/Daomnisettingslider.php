<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Daomnisettingslider extends Model
{
    protected $table = 'daomni_setting_sliders';
}
