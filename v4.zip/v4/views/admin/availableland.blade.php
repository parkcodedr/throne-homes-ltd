@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.availableland')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
