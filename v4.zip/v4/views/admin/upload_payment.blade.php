@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.upload_payment')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
