@extends ('admin.main')

@push('css')


@endpush

@section('content')

<!-- start navigation -->
  @include('admin.backlayouts.list_hall_numbers')
<!-- end navigation -->




@endsection
@push('scripts')


@endpush