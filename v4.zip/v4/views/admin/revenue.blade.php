@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.revenue')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
