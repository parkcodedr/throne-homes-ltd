@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.resetcode')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
