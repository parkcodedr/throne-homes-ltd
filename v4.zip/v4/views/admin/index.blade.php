@extends ('admin.main')

@push('css')


@endpush

@section('content')

<!-- start navigation -->
  @include('admin.backlayouts.main_main')
<!-- end navigation -->




@endsection
@push('scripts')


@endpush