@extends ('admin.main')

@push('css')


@endpush

@section('content')

<!-- start navigation -->
  @include('admin.backlayouts.add_land')
<!-- end navigation -->




@endsection
@push('scripts')


@endpush