@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.land_price')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
