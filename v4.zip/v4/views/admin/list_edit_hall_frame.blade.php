@extends ('admin.main')

@push('css')


@endpush

@section('content')

<!-- start navigation -->
  @include('admin.backlayouts.list_edit_hall')
<!-- end navigation -->




@endsection
@push('scripts')


@endpush