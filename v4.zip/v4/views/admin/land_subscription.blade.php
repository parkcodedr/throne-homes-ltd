@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.land_subscription')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
