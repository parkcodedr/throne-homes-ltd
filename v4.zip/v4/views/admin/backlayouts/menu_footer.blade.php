<footer>
  <div class="pull-right">
    {{ 'Hotel Management System by '  }} <a href="https://daomnitraders.com">DaomniLab</a>
  </div>
  <div class="clearfix"></div>
</footer>