@extends ('admin.main')

@push('css')


@endpush

@section('content')

<!-- start navigation -->
  @include('admin.backlayouts.checked_in_list')
<!-- end navigation -->




@endsection
@push('scripts')


@endpush