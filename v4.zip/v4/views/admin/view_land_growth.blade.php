@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.view_land_growth')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
