<?php

namespace App\Http\Controllers;

use App\Daomniorder;
use Illuminate\Http\Request;

class DaomniorderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Daomniorder  $daomniorder
     * @return \Illuminate\Http\Response
     */
    public function show(Daomniorder $daomniorder)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Daomniorder  $daomniorder
     * @return \Illuminate\Http\Response
     */
    public function edit(Daomniorder $daomniorder)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Daomniorder  $daomniorder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Daomniorder $daomniorder)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Daomniorder  $daomniorder
     * @return \Illuminate\Http\Response
     */
    public function destroy(Daomniorder $daomniorder)
    {
        //
    }
}
