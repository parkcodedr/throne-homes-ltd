@extends ('home.receipt_main')

@push('css')


@endpush

@section('content')

<!-- start footer -->
  @include('home.frontlayouts.receipt_receipt_main')
<!-- end footer -->

@endsection
@push('scripts')


@endpush