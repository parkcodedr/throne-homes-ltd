@extends ('admin.main')

@push('css')


@endpush

@section('content')

    <!-- start navigation -->
    @include('admin.backlayouts.all_orders')
    <!-- end navigation -->




@endsection
@push('scripts')


@endpush
