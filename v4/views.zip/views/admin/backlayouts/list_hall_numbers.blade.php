<div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">

            <!-- sidebar menu -->
              @include('admin.backlayouts.sidebar_menu')
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
              @include('admin.backlayouts.menu_footer_buttons')
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
          @include('admin.backlayouts.top_navigation')
        <!-- /top navigation -->
<!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>@if($display_enabled==1) List & Edit Roomtypes @else List of Rooms & Rates @endif</h3>
                </div>

                <div class="title_right">
                    <div class="col-md-5 col-sm-5   form-group pull-right top_search">
                        <nav aria-label="breadcrumb" >
                            <ol class="breadcrumb pull-right" style="background: none">
                                <li class="breadcrumb-item"><a href="{{ url('/home') }}">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Structural Settings</a></li>
                                <li class="breadcrumb-item active" aria-current="page">List and Edit Roomtypes</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div>

            <div class="row" style="display: block;">
                <div class="col-md-12 col-sm-12">
                    <div class="x_panel">
                        <div class="x_title">
<!--                                <h2>Default Example <small>Users</small></h2>-->
                            <a href="{{ url('/view_edit_hall/0') }}" class="btn btn-success btn-sm pull-right text-white mt-3 mb-3"><i class="fa fa-plus"></i> &nbsp; Add New Hall &nbsp; </a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            @if(strtolower($role)=='super'||strtolower($role)=='admin'||strtolower($role)=='frontdesk')
                            <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Hall Name</th>
                                    <th>Hall Number</th>
                                    <th>Current Booking ID</th>
                                    <th>Check-out Time</th>
                                    @if(strtolower($role)=='super'||strtolower($role)=='admin')
                                        @if($display_enabled==1)
                                            <th>Manage</th>
                                        @endif
                                    @endif
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($roomnumbers as $roomnumber)
                                    <tr>
                                        <td scope="row">{{ $roomnumber->id }}</td>
                                        <td>{{ ucfirst(strtolower($roomnumber->GetRoomData($roomnumber->roomtypes_id,$admin_id)["room_name"])).' '.strtolower($group) }}</td>
                                        <td>{{ $roomnumber->room_number }}</td>
                                        <td>{{ $roomnumber->current_booking_id }}</td>
                                        <td>{{ $roomnumber->auto_checkout_time }}</td>
                                    @if(strtolower($role)=='super'||strtolower($role)=='admin')
                                        @if($display_enabled==1)
                                            <td><a href="#">View/Edit</a></td>
                                        @endif
                                    @endif
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                            @endif
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- /page content -->

          <div class="row">

          </div>



            <div class="col-md-8 col-sm-8 ">



              <div class="row">

              </div>
              <div class="row">


                <!-- Start to do list -->
                <div class="col-md-6 col-sm-6 ">

                </div>
                <!-- End to do list -->
                
                <!-- start of weather widget -->
                <div class="col-md-6 col-sm-6 ">
                

                </div>
                <!-- end of weather widget -->
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        @include('admin.backlayouts.menu_footer')
        <!-- /footer content -->
      </div>
    </div>
